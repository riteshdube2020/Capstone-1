import React from 'react';
import { connect } from 'react-redux';
import {getUsersearch} from '../actions/feedbacks';
import FeedbackList1 from './FeedbackList1';


 class UsersearchList extends React.Component{

    constructor(props) {
        super(props); 
        this.onUseridChange = this.onUseridChange.bind(this);       
       // this.handleClick = this.handleClick.bind(this);        
        this.state = {
            userid:""            
            }
        }
    // this.handleClick = event => {
    //     this.setState({
    //         userid: event.target.value       
    // })
    // //     this.setState({
    // //         userid:""
    // // })
    //     props.dispatch(getUsersearch(this.state.userid));
    // }}
    onUseridChange(e) {
        const userid = e.target.value;
        this.setState(() => ({ userid: userid }));
    }
     

render() { 
    console.log("inside render of user search");
    return (
        <div>
            <form> 
            <input type="text" placeholder="User-ID"            
            value={this.state.userid}
              onChange={this.onUseridChange}>
            </input> 

            <button onClick={event => {
                console.log("button click");
                this.props.dispatch(getUsersearch(this.state.userid));
            //  this.setState({
              // userid: event.target.value       
             //  })
    //     this.setState({
    //         userid:""
    // })
              
    }}>Search</button> 
      </form>  
      <div className='container__list'>
        {/* <FeedbackList1 /> */}
    </div>

        </div>
    );

    }
}

// onSubmitFeedback={(feedback) => {
//     props.dispatch(addFeedback(feedback));
//     props.history.push('/');
// }}


// const mapStateToProps = (state) => {
//     return {
//         feedbacks: state
//     };
// }

export default connect()(UsersearchList);






