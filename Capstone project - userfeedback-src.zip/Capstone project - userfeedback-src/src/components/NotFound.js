import React from 'react';

const NotFound = () => (
    <div>
        404!
    </div>
);

export default NotFound;